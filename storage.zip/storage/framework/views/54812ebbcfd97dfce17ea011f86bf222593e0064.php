<!--FOOTER-->
<footer>
    <div id="lgx-footer" class="lgx-footer-black"> <!--lgx-footer-white-->
        <div class="lgx-inner-footer">
            <div class="container-fluid">
                
                <div class="lgx-footer-area footer-custom-menu">
                    <div class="lgx-footer-single footer-brand">
                        <img class="footer-brand-logo" src="/storage/<?php echo e(setting('site.logo')); ?>" alt="<?php echo e(setting('site.site_name')); ?>" />
                        <p class="footer-brand-name"><?php echo e(setting('site.site_name')); ?></p>
                        <p class="footer-brand-slogan"><?php echo e(setting('site.site_slogan')); ?></p>
                    </div>

                    <div class="lgx-footer-single">
                        <h3 class="footer-title"><?php echo app('translator')->get('eventmie-pro::em.useful_links'); ?></h3>
                        <ul class="list-unstyled">
                            <li><a class="col-grey" href="<?php echo e(route('eventmie.page', ['page' => 'about'])); ?>"><?php echo app('translator')->get('eventmie-pro::em.about'); ?></a></li>
                            <li><a class="col-grey" href="<?php echo e(route('eventmie.events_index')); ?>"><?php echo app('translator')->get('eventmie-pro::em.events'); ?></a></li>
                            <li><a class="col-grey" href="<?php echo e(route('eventmie.get_posts')); ?>"><?php echo app('translator')->get('eventmie-pro::em.blogs'); ?></a></li>
                            <li><a class="col-grey" href="<?php echo e(route('eventmie.page', ['page' => 'terms'])); ?>"><?php echo app('translator')->get('eventmie-pro::em.terms'); ?></a></li>
                            <li><a class="col-grey" href="<?php echo e(route('eventmie.page', ['page' => 'privacy'])); ?>"><?php echo app('translator')->get('eventmie-pro::em.privacy'); ?></a></li>
                        </ul>
                    </div>
                    <div class="lgx-footer-single">
                        <h3 class="footer-title"><?php echo app('translator')->get('eventmie-pro::em.contact'); ?></h3>
                        <a href="<?php echo e(route('eventmie.contact')); ?>">
                            <h4 class="date"><?php echo app('translator')->get('eventmie-pro::em.contact_send_message'); ?></h4>
                        </a>
                        <address><?php echo e(setting('contact.address')); ?></address>
                        <p class="text"><i class="fas fa-phone-alt"></i> <?php echo e(setting('contact.phone')); ?></p>
                        <p class="text"><i class="fas fa-envelope"></i> <?php echo e(setting('contact.email')); ?></p>
                        
                        <a href="<?php echo e(route('eventmie.contact')); ?>" class="map-link">
                            <i class="fas fa-map-marked-alt" aria-hidden="true"></i> 
                            <?php echo app('translator')->get('eventmie-pro::em.contact_find_us'); ?>
                        </a>
                    </div>
                    <div class="lgx-footer-single">
                        <h3 class="footer-title"><?php echo app('translator')->get('eventmie-pro::em.social'); ?></h3>
                        <p class="text"><?php echo app('translator')->get('eventmie-pro::em.social_find'); ?></p>
                        <ul class="list-inline lgx-social-footer">
                            <?php if(setting('social.facebook')): ?>
                            <li><a href="<?php echo e('https://www.facebook.com/'.setting('social.facebook')); ?>" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                            <?php endif; ?>

                            <?php if(setting('social.twitter')): ?>
                            <li><a href="<?php echo e('https://twitter.com/'.setting('social.twitter')); ?>" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            
                            <?php if(setting('social.instagram')): ?>
                            <li><a href="<?php echo e(setting('social.instagram')); ?>" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                            
                            <?php if(setting('social.linkedin')): ?>
                            <li><a href="<?php echo e(setting('social.linkedin')); ?>" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                  
                </div>


                
                <?php $footerMenuItems = footerMenu() ?>
                <?php if(!empty($footerMenuItems)): ?>
                <div class="lgx-footer-area footer-custom-menu">
                    <div class="lgx-footer-single"></div>
                    
                    <?php $key = 1; ?>
                    <?php $__currentLoopData = $footerMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="lgx-footer-single">
                        <h3 class="footer-title"><i class="<?php echo e($parentItem->icon_class); ?>"></i> <?php echo e($parentItem->title); ?></h3>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $parentItem->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="col-grey" target="<?php echo e($childItem->target); ?>" href="<?php echo e($childItem->url); ?>">
                                    <i class="<?php echo e($childItem->icon_class); ?>"></i> <?php echo e($childItem->title); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <?php if(!($key%3)): ?>
                    <div class="flex-break"></div>
                    <div class="lgx-footer-single"></div>
                    <?php endif; ?>

                    <?php $key++; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <div class="lgx-footer-bottom lgx-footer-single pb-4">
                    <ul class="list-inline">
                        <?php $__currentLoopData = lang_selector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-inline-item border-seperator">
                            <a class="col-grey <?php echo e($val == config('app.locale') ? 'active' : ''); ?>" href="<?php echo e(route('eventmie.change_lang', ['lang' => $val])); ?>"><?php echo app('translator')->get('eventmie-pro::em.lang_'.$val); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                
                <div class="lgx-footer-bottom">
                    <div class="lgx-copyright">
                        <p> 
                            <span>©</span> <?php echo e(date('Y')); ?> 
                            <a href="<?php echo e(eventmie_url()); ?>"><?php echo e((setting('site.site_name') ? setting('site.site_name') : config('app.name'))); ?></a><br>

                            <?php if(!empty(setting('site.site_footer'))): ?> 
                            <?php echo setting('site.site_footer'); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>

            </div>
            <!-- //.CONTAINER -->
        </div>
        <!-- //.footer Middle -->
    </div>
</footer>
<!--FOOTER END--><?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/layouts/footer.blade.php ENDPATH**/ ?>