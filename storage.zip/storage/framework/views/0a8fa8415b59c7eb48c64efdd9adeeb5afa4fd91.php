<li>
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.login')); ?>"><i class="fas fa-fingerprint"></i> <?php echo app('translator')->get('eventmie-pro::em.login'); ?></a>
</li>
<li>
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.register_show')); ?>"><i class="fas fa-user-plus"></i> <?php echo app('translator')->get('eventmie-pro::em.register'); ?></a>
</li><?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/layouts/guest_header.blade.php ENDPATH**/ ?>