<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($mail_data->mail_subject); ?>


<?php echo e($mail_data->mail_message); ?>


<?php $__currentLoopData = $extra_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- <?php echo e($val); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->startComponent('mail::button', ['url' => $mail_data->action_url]); ?>
<?php echo e($mail_data->action_title); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo e(__('eventmie-pro::em.thank_you')); ?><br>
<?php echo e((setting('site.site_name') ? setting('site.site_name') : config('app.name'))); ?> - [<?php echo e(trim(eventmie_url(), '/')); ?>](<?php echo e(eventmie_url()); ?>)
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/mail/common.blade.php ENDPATH**/ ?>