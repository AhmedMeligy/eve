<!-- Packages CSS -->
<link rel="stylesheet" href="<?php echo e(eventmie_asset('css/vendor_v1.8.css')); ?>">

<!-- Bootstrap RTL CSS only if langauge is RTL -->
<?php if(is_rtl()): ?>
<link rel="stylesheet" href="<?php echo e(eventmie_asset('css/bootstrap-rtl.min.css')); ?>">
<?php endif; ?>



<!-- App CSS -->
<link rel="stylesheet" href="<?php echo e(eventmie_asset('css/app_v1.8.css')); ?>">
<?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/layouts/include_css.blade.php ENDPATH**/ ?>