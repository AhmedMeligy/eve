<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('eventmie-pro::em.blogs'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main>
    <div class="lgx-page-wrapper">
        <!--Blogs-->
        <section>
            <div class="container">
                <div class="row">
                    <?php if(!empty($posts)): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-sm-6 col-lg-4">
                            <div class="lgx-single-news">
                                <figure>
                                    <a href="<?php echo e(route('eventmie.post_view', $item['slug'])); ?>">
                                        <img src="/storage/<?php echo e($item['image']); ?>" alt="">
                                    </a>
                                </figure>
                                
                                <div class="single-news-info">
                                    <div class="meta-wrapper hidden">
                                        <span><?php echo e(\Carbon\Carbon::parse($item['updated_at'])->translatedFormat(format_carbon_date())); ?></span>
                                    </div>
                                
                                    <h3 class="title">
                                        <a href="<?php echo e(route('eventmie.post_view', $item['slug'])); ?>"><?php echo e($item['title']); ?></a>
                                    </h3>

                                    <div class="meta-wrapper">
                                        <span><?php echo e($item['excerpt']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <div class="col-md-12">
                        <h4 class="text-center"><?php echo app('translator')->get('eventmie-pro::em.nothing'); ?></h4>
                    </div>
                    <?php endif; ?>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>
            </div><!-- //.CONTAINER -->
        </section>
        <!--Blogs END-->
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('eventmie::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/blogs/index.blade.php ENDPATH**/ ?>