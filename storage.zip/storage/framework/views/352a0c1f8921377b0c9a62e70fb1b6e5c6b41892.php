<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\wamp64\www\even2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>