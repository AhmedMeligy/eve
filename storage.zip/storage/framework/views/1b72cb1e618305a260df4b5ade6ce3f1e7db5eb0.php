
<li>
    <?php
        $data  = notifications();
    ?>

    <a id="navbarDropdown" class="dropdown-toggle active" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
        <i class="fas fa-bell"> </i> 
        <span class="badge bg-red"><?php echo e($data['total_notify']); ?></span> 
        <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
        <?php if(!empty($data['notifications'])): ?>      
            <?php $__currentLoopData = $data['notifications']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <li>
                <a class="dropdown-item" href="<?php echo e(route('eventmie.notify_read', [$notification->n_type])); ?>"> 
                    <?php echo e($notification->total); ?> 
                    <?php if($notification->n_type == 'user'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.user'); ?>
                    <?php elseif($notification->n_type == 'cancel'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.booking_cancellation'); ?>
                    <?php elseif($notification->n_type == 'review'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.show_reviews'); ?>
                    <?php elseif($notification->n_type == 'contact'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.contact'); ?>
                    <?php elseif($notification->n_type == 'events'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.event'); ?>
                    <?php elseif($notification->n_type == 'Approve-Organizer'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.requested_to_become_organiser'); ?>
                    <?php elseif($notification->n_type == 'Approved-Organizer'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.became_organiser_successful'); ?>
                    <?php elseif($notification->n_type == 'bookings'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.booking'); ?>
                    <?php elseif($notification->n_type == 'forgot_password'): ?>
                        <?php echo app('translator')->get('eventmie-pro::em.reset_password'); ?>
                    <?php endif; ?>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <li>
            <a class="dropdown-item" > <?php echo app('translator')->get('eventmie-pro::em.no_notifications'); ?></a>
        </li>
        <?php endif; ?>
    </ul>
</li>


<li>
    <a id="navbarDropdown" class="dropdown-toggle active" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
        <?php if(Auth::user()->hasRole('customer')): ?>
        <i class="fas fa-user-circle"></i> 
        <?php elseif(Auth::user()->hasRole('organiser')): ?>
        <i class="fas fa-person-booth"></i> 
        <?php else: ?>
        <i class="fas fa-user-shield"></i> 
        <?php endif; ?>

        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
    </a>
    <ul class="dropdown-menu multi-level">

        
        <?php if(Auth::user()->hasRole('customer')): ?>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.profile')); ?>"><i class="fas fa-id-card"></i> <?php echo app('translator')->get('eventmie-pro::em.profile'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.mybookings_index')); ?>"><i class="fas fa-money-check-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.mybookings'); ?></a>
        </li>
        <?php endif; ?>

        
        <?php if(Auth::user()->hasRole('organiser')): ?>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.profile')); ?>"><i class="fas fa-id-card"></i> <?php echo app('translator')->get('eventmie-pro::em.profile'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.organizer_dashboard')); ?>"><i class="fas fa-tachometer-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.dashboard'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.ticket_scan')); ?>"><i class="fas fa-qrcode"></i> <?php echo app('translator')->get('eventmie-pro::em.scan_ticket'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.myevents_form')); ?>"><i class="fas fa-calendar-plus"></i> <?php echo app('translator')->get('eventmie-pro::em.create_event'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.myevents_index')); ?>"><i class="fas fa-calendar-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.manage_events'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.obookings_index')); ?>"><i class="fas fa-money-check-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.manage_bookings'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.event_earning_index')); ?>"><i class="fas fa-wallet"></i> <?php echo app('translator')->get('eventmie-pro::em.manage_earning'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.tags_form')); ?>"><i class="fas fa-user-tag"></i> <?php echo app('translator')->get('eventmie-pro::em.manage_tags'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.myvenues.index')); ?>"><i class="fas fa-location-arrow"></i> <?php echo app('translator')->get('eventmie-pro::em.manage_venues'); ?></a>
        </li>
        <?php endif; ?>

        
        <?php if(Auth::user()->hasRole('admin')): ?>
        <li>
            <a class="dropdown-item" href="<?php echo e(eventmie_url().'/'.config('eventmie.route.admin_prefix')); ?>">
            <i class="fas fa-tachometer-alt"></i>  <?php echo app('translator')->get('eventmie-pro::em.admin_panel'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.profile')); ?>"><i class="fas fa-id-card"></i> <?php echo app('translator')->get('eventmie-pro::em.profile'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.ticket_scan')); ?>"><i class="fas fa-qrcode"></i> <?php echo app('translator')->get('eventmie-pro::em.scan_ticket'); ?></a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.myevents_form')); ?>"><i class="fas fa-calendar-plus"></i> <?php echo app('translator')->get('eventmie-pro::em.create_event'); ?></a>
        </li>
        <?php endif; ?>

        <li>
            <a class="dropdown-item" href="<?php echo e(route('eventmie.logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.logout'); ?>
            </a>
            <form id="logout-form" action="<?php echo e(route('eventmie.logout')); ?>" method="POST" style="display: none;">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            </form>
        </li>
    </ul>
</li>


<?php if(Auth::user()->hasRole('admin')): ?>
<li class="hide-ipad">
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.ticket_scan')); ?>">
    <i class="fas fa-qrcode"></i> <?php echo app('translator')->get('eventmie-pro::em.scan_ticket'); ?></a>
</li>
<li class="hide-ipad">
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.myevents_form')); ?>">
    <i class="fas fa-calendar-plus"></i> <?php echo app('translator')->get('eventmie-pro::em.create_event'); ?></a>
</li>
<?php endif; ?>


<?php if(Auth::user()->hasRole('organiser')): ?>
<li class="hide-ipad">
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.ticket_scan')); ?>">
    <i class="fas fa-qrcode"></i> <?php echo app('translator')->get('eventmie-pro::em.scan_ticket'); ?></a>
</li>
<li class="hide-ipad">
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.myevents_form')); ?>">
    <i class="fas fa-calendar-plus"></i> <?php echo app('translator')->get('eventmie-pro::em.create_event'); ?></a>
</li>
<?php endif; ?>



<?php if(Auth::user()->hasRole('customer')): ?>
<li class="hide-ipad">
    <a class="lgx-scroll" href="<?php echo e(route('eventmie.mybookings_index')); ?>">
    <i class="fas fa-money-check-alt"></i> <?php echo app('translator')->get('eventmie-pro::em.mybookings'); ?></a>
</li>
<?php endif; ?><?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/layouts/member_header.blade.php ENDPATH**/ ?>