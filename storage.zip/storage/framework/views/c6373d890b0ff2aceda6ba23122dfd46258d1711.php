<header>
    <div class="lgx-header">
        <div id="navbar_vue" class="lgx-header-position lgx-header-position-white lgx-header-position-fixed">
            <div class="lgx-container-fluid" >
                <!-- GDPR -->
                <cookie-law theme="gdpr" button-text="<?php echo app('translator')->get('eventmie-pro::em.accept'); ?>">
                    <div slot="message">
                        <gdpr-message></gdpr-message>
                    </div>
                </cookie-law>
                <!-- GDPR -->

                <!-- Vue Alert message -->
                <?php if($errors->any()): ?>
                    <alert-message :errors="<?php echo e(json_encode($errors->all(), JSON_HEX_APOS)); ?>"></alert-message>    
                <?php endif; ?>

                <?php if(session('status')): ?>
                    <alert-message :message="'<?php echo e(session('status')); ?>'"></alert-message>    
                <?php endif; ?>
                <!-- Vue Alert message -->

                <nav class="navbar navbar-default lgx-navbar navbar-expand-lg">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" onclick="document.getElementById('navbar').classList.toggle('in')">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="lgx-logo">
                            <a href="<?php echo e(eventmie_url()); ?>" class="lgx-scroll">
                                <img src="/storage/<?php echo e(setting('site.logo')); ?>" alt="<?php echo e(setting('site.site_name')); ?>"/>
                                <span class="brand-name"><?php echo e(setting('site.site_name')); ?></span>
                                <span class="brand-slogan"><?php echo e(setting('site.site_slogan')); ?></span>
                            </a>
                        </div>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse">
                        <ul class="nav navbar-nav lgx-nav navbar-right">
                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <?php echo $__env->make('eventmie::layouts.guest_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('eventmie::layouts.member_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>

                            <li>
                                <a class="lgx-scroll" href="<?php echo e(route('eventmie.venues.index')); ?>"><i class="fas fa-map-marker"></i> <?php echo app('translator')->get('eventmie-pro::em.venues'); ?></a>
                            </li>

                            
                            
                            <?php $categoriesMenu = categoriesMenu() ?>
                            <?php if(!empty($categoriesMenu)): ?>
                            <li>
                                <a id="navbarDropdown" class="dropdown-toggle active" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fas fa-stream"></i> <?php echo app('translator')->get('eventmie-pro::em.categories'); ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu multi-level">
                                    <?php $__currentLoopData = $categoriesMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a class="lgx-scroll" href="<?php echo e(route('eventmie.events_index', ['category' => urlencode($val->name)])); ?>">
                                            <?php echo e($val->name); ?>

                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php endif; ?>

                            
                            <?php $headerMenuItems = headerMenu() ?>
                            <?php if(!empty($headerMenuItems)): ?>
                            <li class="custom-menu">
                                <a id="navbarDropdown" class="dropdown-toggle active" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <i class="fas fa-th"></i> <?php echo app('translator')->get('eventmie-pro::em.more'); ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu multi-level">
                                    <?php $__currentLoopData = $headerMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!empty($parentItem->submenu)): ?> 
                                        <li class="dropdown-submenu">
                                            <a disabled class="dropdown-toggle disabled" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="<?php echo e($parentItem->icon_class); ?>"></i> <?php echo e($parentItem->title); ?> &nbsp;&nbsp;<i class="fas fa-angle-right"></i></a>
                                            <ul class="dropdown-menu">
                                                <?php $__currentLoopData = $parentItem->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a target="<?php echo e($childItem->target); ?>" href="<?php echo e($childItem->url); ?>">
                                                        <i class="<?php echo e($childItem->icon_class); ?>"></i> <?php echo e($childItem->title); ?>

                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        <?php else: ?>
                                        <li>
                                            <a class="lgx-scroll" target="<?php echo e($parentItem->target); ?>" href="<?php echo e($parentItem->url); ?>">
                                                <i class="<?php echo e($parentItem->icon_class); ?>"></i> <?php echo e($parentItem->title); ?>

                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <?php endif; ?>

                            <li>
                                <a class="lgx-scroll lgx-btn lgx-btn-sm" href="<?php echo e(route('eventmie.events_index')); ?>"><i class="fas fa-calendar-day"></i> <?php echo app('translator')->get('eventmie-pro::em.browse_events'); ?></a>
                            </li>
                            
                        </ul>
                    </div><!--/.nav-collapse -->
                </nav>
            </div>
            <!-- //.CONTAINER -->
        </div>
    </div>
</header><?php /**PATH C:\wamp64\www\even2\eventmie-pro\src/../resources/views/layouts/header.blade.php ENDPATH**/ ?>