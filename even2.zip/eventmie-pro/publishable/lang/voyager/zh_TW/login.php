<?php

return [
    'loggingin'    => '正在登入',
    'signin_below' => '在下方登入：',
    'welcome'      => '歡迎使用 Voyager - 不可錯過的 Laravel 後台管理框架',
];
