<?php

return [
    'last_week' => 'पिछले सप्ताह',
    'last_year' => 'पिछले साल',
    'this_week' => 'इस सप्ताह',
    'this_year' => 'इस साल',
];
