<?php

return [
    'additional_fields'=> 'अतिरिक्त क्षेत्र',
    'category'         => 'पोस्ट श्रेणी',
    'content'          => 'पोस्ट सामग्री',
    'details'          => 'पोस्ट विवरण',
    'excerpt'          => 'अंश <small> इस पोस्ट का छोटा विवरण </ small>',
    'image'            => 'पोस्ट इमेज',
    'meta_description' => 'मेटा विवरण',
    'meta_keywords'    => 'मेटा कीवर्ड',
    'new'              => 'नई पोस्ट बनाएँ',
    'seo_content'      => 'एसईओ सामग्री',
    'seo_title'        => 'एसईओ शीर्षक',
    'slug'             => 'URL स्लग',
    'status'           => 'पोस्ट की स्थिति',
    'status_draft'     => 'प्रारूप',
    'status_pending'   => 'लंबित',
    'status_published' => 'प्रकाशित',
    'title'            => 'शीर्षक पोस्ट करें',
    'title_sub'        => 'आपकी पोस्ट का शीर्षक',
    'update'           => 'अपडेट पोस्ट',
];
