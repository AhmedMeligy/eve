<?php

return [
    'footer_copyright'  => 'Gemacht mit <i class="voyager-heart"></i> von',
    'footer_copyright2' => 'Gemacht mit Rum und noch mehr Rum',
];
