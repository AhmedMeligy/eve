<?php

return [
    'invalid'           => '無効なJSONです',
    'invalid_message'   => '無効なJSONを導入したようです',
    'valid'             => '有効なJSON',
    'validation_errors' => 'バリデーションエラー',
];
