<?php

return [
    'avatar'           => '头像',
    'edit'             => '更改个人资料',
    'edit_user'        => '编辑用户',
    'password'         => '密码',
    'password_hint'    => '留空为不修改密码',
    'role'             => '权限',
    'roles'            => '角色',
    'role_default'     => '默认角色',
    'roles_additional' => '其他角色',
    'user_role'        => '用户权限',
];
