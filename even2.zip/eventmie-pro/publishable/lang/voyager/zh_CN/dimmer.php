<?php

return [
    'page'           => '页面|页面',
    'page_link_text' => '查看所有页面',
    'page_text'      => '您有 :count :string 在数据库中。点击下面的按钮查看所有页面。',
    'post'           => '文章|文章',
    'post_link_text' => '查看所有的帖子',
    'post_text'      => '您有 :count :string 在数据库中。点击下面的按钮查看所有文章。',
    'user'           => '用户|用户',
    'user_link_text' => '查看所有用户',
    'user_text'      => '您有 :count :string 在数据库中。点击下面的按钮查看所有用户。',
];
