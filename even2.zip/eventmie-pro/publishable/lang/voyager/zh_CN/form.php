<?php

return [
    'field_password_keep'          => '留空以保持不变',
    'field_select_dd_relationship' => '确保在 :class 类的 :method 方法中设置适当的关系。',
    'type_checkbox'                => '复选框',
    'type_codeeditor'              => '代码编辑器',
    'type_file'                    => '文件',
    'type_image'                   => '图像',
    'type_radiobutton'             => '单选按钮',
    'type_richtextbox'             => '富文本框',
    'type_selectdropdown'          => '选择下拉',
    'type_textarea'                => '文本区域',
    'type_textbox'                 => '文本框',
];
